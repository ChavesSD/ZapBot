export default {
  event: 'event',
  status: 'ack',
  id: 'id._serialized',
  session: 'session',
  timestamp: 't',
};
